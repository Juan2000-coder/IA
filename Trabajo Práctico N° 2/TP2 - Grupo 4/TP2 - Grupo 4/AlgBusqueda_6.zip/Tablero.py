from Nodo import nodo


class tablero:

  def __init__(self):

    #Creamos los nodos
    self.nodo_A = nodo('A', [4, 4])
    self.nodo_B = nodo('B', [5, 4])
    self.nodo_C = nodo('C', [4, 3])
    self.nodo_D = nodo('D', [5, 3])
    self.nodo_E = nodo('E', [6, 3])
    self.nodo_F = nodo('F', [5, 1])
    self.nodo_G = nodo('G', [1, 2])
    self.nodo_I = nodo('I', [2, 2])
    self.nodo_K = nodo('K', [4, 2])
    self.nodo_M = nodo('M', [5, 2])
    self.nodo_N = nodo('N', [6, 2])
    self.nodo_P = nodo('P', [1, 1])
    self.nodo_Q = nodo('Q', [2, 1])
    self.nodo_R = nodo('R', [3, 1])
    self.nodo_T = nodo('T', [4, 1])
    self.nodo_W = nodo('W', [3, 2])

    #Definimos el nodo de inicio y de fin de la ruta que deseamos lograr
    self.nodo_inicial = self.nodo_I
    self.nodo_final = self.nodo_F

    #Definimos heurísticas
    self.calc_heur(self.nodo_A, self.nodo_final)
    self.calc_heur(self.nodo_B, self.nodo_final)
    self.calc_heur(self.nodo_C, self.nodo_final)
    self.calc_heur(self.nodo_D, self.nodo_final)
    self.calc_heur(self.nodo_E, self.nodo_final)
    self.calc_heur(self.nodo_F, self.nodo_final)
    self.calc_heur(self.nodo_G, self.nodo_final)
    self.calc_heur(self.nodo_I, self.nodo_final)
    self.calc_heur(self.nodo_K, self.nodo_final)
    self.calc_heur(self.nodo_M, self.nodo_final)
    self.calc_heur(self.nodo_N, self.nodo_final)
    self.calc_heur(self.nodo_P, self.nodo_final)
    self.calc_heur(self.nodo_Q, self.nodo_final)
    self.calc_heur(self.nodo_R, self.nodo_final)
    self.calc_heur(self.nodo_T, self.nodo_final)
    self.calc_heur(self.nodo_W, self.nodo_final)
    
    # Se establecen las relaciones padre-hijo
    #Nodo A
    self.nodo_A.agregar_hijos(self.nodo_B, 1)
    self.nodo_A.agregar_hijos(self.nodo_C, 1)
    #Nodo B
    self.nodo_B.agregar_hijos(self.nodo_A, 1)
    self.nodo_B.agregar_hijos(self.nodo_D, 1)
    #Nodo C
    self.nodo_C.agregar_hijos(self.nodo_A, 1)
    self.nodo_C.agregar_hijos(self.nodo_K, 1)
    #Nodo D
    self.nodo_D.agregar_hijos(self.nodo_B, 1)
    self.nodo_D.agregar_hijos(self.nodo_M, 1)
    #Nodo E
    self.nodo_E.agregar_hijos(self.nodo_N, 1)
    #Nodo F
    self.nodo_F.agregar_hijos(self.nodo_M, 1)
    #Nodo G
    self.nodo_G.agregar_hijos(self.nodo_I, 1)
    self.nodo_G.agregar_hijos(self.nodo_P, 1)
    #Nodo I
    self.nodo_I.agregar_hijos(self.nodo_G, 1)
    self.nodo_I.agregar_hijos(self.nodo_Q, 1)
    self.nodo_I.agregar_hijos(self.nodo_W, 30)
    #Nodo K
    self.nodo_K.agregar_hijos(self.nodo_C, 1)
    self.nodo_K.agregar_hijos(self.nodo_M, 1)
    self.nodo_K.agregar_hijos(self.nodo_T, 1)
    self.nodo_K.agregar_hijos(self.nodo_W, 30)
    #Nodo M
    self.nodo_M.agregar_hijos(self.nodo_D, 1)
    self.nodo_M.agregar_hijos(self.nodo_F, 1)
    self.nodo_M.agregar_hijos(self.nodo_K, 1)
    self.nodo_M.agregar_hijos(self.nodo_N, 1)
    #Nodo N
    self.nodo_N.agregar_hijos(self.nodo_E, 1)
    self.nodo_N.agregar_hijos(self.nodo_M, 1)
    #Nodo P
    self.nodo_P.agregar_hijos(self.nodo_G, 1)
    self.nodo_P.agregar_hijos(self.nodo_Q, 1)
    #Nodo Q
    self.nodo_Q.agregar_hijos(self.nodo_I, 1)
    self.nodo_Q.agregar_hijos(self.nodo_P, 1)
    self.nodo_Q.agregar_hijos(self.nodo_R, 1)
    #Nodo R
    self.nodo_R.agregar_hijos(self.nodo_Q, 1)
    self.nodo_R.agregar_hijos(self.nodo_T, 1)
    #Nodo T
    self.nodo_T.agregar_hijos(self.nodo_K, 1)
    self.nodo_T.agregar_hijos(self.nodo_R, 1)
    #Nodo W
    self.nodo_W.agregar_hijos(self.nodo_I, 1)
    self.nodo_W.agregar_hijos(self.nodo_K, 1)

  def calc_heur(self, nodo, nodo_final):
    nodo.heur = abs(nodo_final.pos[0] - nodo.pos[0]) + nodo.heur
    nodo.heur = abs(nodo_final.pos[1] - nodo.pos[1]) + nodo.heur

    # Defino las restricciones de pared, que implican aumentar en 2 unidades 
      # el valor del camino, debido a la curva que debe hacer

    #Se debe tener en cuenta esta excepción, pq sino al rev si está en la misma
      #le suma 2 unidades a su heurística
    if (nodo.pos != nodo_final.pos):
      #Pared entre T y F
      if (nodo.pos[1] == nodo_final.pos[1] == 1):
        nodo.heur = nodo.heur + 2
      #Pared entre R y W
      if (nodo.pos[0] == nodo_final.pos[0] == 3):
        nodo.heur = nodo.heur + 2
      #Pared CD y DE
      if (nodo.pos[1] == nodo_final.pos[1] == 3):
        nodo.heur = nodo.heur + 2

class nodo:
    def __init__(self, nombre, pos):
        # Constructor de la clase nodo
        # Inicializa propiedades del nodo con los valores proporcionados
        self.nombre = nombre
        self.pos = pos
        self.heur = 0
        self.hijos = []
        self.costo_hijos = {}
        self.nodo_padre = 0

    def agregar_hijos(self, nodo_hijo, costo_hijo):
        # Método para agregar nodos hijos
        self.hijos.append(nodo_hijo)  # Agrega el nodo hijo a la lista de hijos
        self.costo_hijos[nodo_hijo.nombre] = costo_hijo  # Asigna el costo al nodo hijo

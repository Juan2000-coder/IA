class alg_primero_mejor:
  
    def __init__(self, nodo_inicio, nodo_final):
        self.ruta = []
        self.nodo_inicio = nodo_inicio
        self.nodo_final = nodo_final

    def run_pm(self):
        nodo = self.nodo_inicio
        self.ruta.append(nodo)

        heur_ant = 30000
        for i in nodo.hijos:
            # Encuentra el nodo hijo con la menor heurística
            if (i.heur < heur_ant) and (i != self.ruta[-1]):
                nodo = i
                heur_ant = i.heur
        self.ruta.append(nodo)

        while nodo != self.nodo_final:
            # Expande los hijos y elige el de la menor heurística
            heur_ant = 30000
            for i in nodo.hijos:
                if (i.heur < heur_ant) and (i != self.ruta[-2]):
                    nodo = i
                    heur_ant = i.heur
            self.ruta.append(nodo)

    def imprimir_ruta_pm(self):
        # Método para imprimir la ruta encontrada por el algoritmo de búsqueda
        print("Estrategia Avara: ")
        print(" ")
        for i in self.ruta:
            print("      ", i.nombre)
        print(" ")

class alg_a_estrella:
  
  def __init__(self, nodo_inicio, nodo_final):
      self.ruta = []
      self.ruta_nueva = []
      self.nodo_inicio = nodo_inicio
      self.nodo_padre = nodo_inicio
      self.nodo_final = nodo_final
      self.buffer = {}

  def run_ae(self):
      nodo = self.nodo_inicio
      self.buffer[nodo] = nodo.heur
      self.ruta.append(nodo)
      
      while nodo != self.nodo_final:
          self.nodo_padre = nodo
          
          costo_ant = 30000
          costo_acum = self.buffer[nodo]
          del self.buffer[nodo]
          
          # Calcula los costos para los nodos hijos no visitados y los agrega al buffer
          for i in nodo.hijos:
              if i not in self.ruta:
                  costo = costo_acum - nodo.heur
                  costo = i.heur + nodo.costo_hijos[i.nombre] + costo
                  self.buffer[i] = costo
                
          # Encuentra el nodo con el costo estimado más bajo en el buffer
          for j in self.buffer:
              if self.buffer[j] < costo_ant:
                  nodo = j
                  costo_ant = self.buffer[j]
          
          indice = self.ruta.index(self.nodo_padre)
        
          # Construye la nueva ruta basada en el nodo padre y el nodo actual
          if indice != -1:
              for k in range(indice + 1):
                  self.ruta_nueva.append(self.ruta[k])
              self.ruta = self.ruta_nueva
              
              self.ruta.append(nodo)
              
          self.ruta_nueva = []

      #Proceso de borrado de nodos no correspondidos. 
      #Son nodos en los que no existe relación padre/hijo con su anterior y/o 
      # posterior, pero siguen apareciendo correctamente en la ruta, por si se
      # llegase a seguir expandiendo el camino y estos se debieran tener en cuenta.
      contador = len(self.ruta) - 1
      i = self.ruta[contador - 1]
      while i != self.nodo_inicio:
          if self.ruta[contador] in i.hijos:
              i = self.ruta[contador - 2]
              contador -= 1
          else:
              self.ruta.remove(i)
              i = self.ruta[contador - 2]
              contador -= 1

  
  def imprimir_ruta_ae(self):
      # Método para imprimir la ruta encontrada por el algoritmo
      print("Estrategia A*: ")
      print(" ")
      for i in self.ruta:
          print("      ", i.nombre)
      print(" ")

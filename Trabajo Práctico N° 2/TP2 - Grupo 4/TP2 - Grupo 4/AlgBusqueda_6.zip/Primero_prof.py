class alg_primero_prof:
  
    def __init__(self, nodo_inicio, nodo_final):
        self.ruta = []
        self.ruta_nueva = []
        self.nodo_inicio = nodo_inicio
        self.nodo_final = nodo_final
        self.buffer = []
        self.contador = 0
        
        self.nodo_padre = nodo_inicio

    def run_pp(self):
        nodo = self.nodo_inicio
        self.buffer.append(nodo)
        self.ruta.append(nodo)

        while nodo != self.nodo_final:
            self.nodo_padre = nodo
            
            del self.buffer[-1]

            # Expande los nodos hijos y agrega al buffer en orden inverso
            for i in reversed(nodo.hijos):
                if i not in self.ruta:
                    self.buffer.append(i)

            nodo = self.buffer[-1]
            self.ruta.append(nodo)

        #Proceso de borrado de nodos no correspondidos. 
        #Son nodos en los que no existe relación padre/hijo con su anterior y/o 
        # posterior, pero siguen apareciendo correctamente en la ruta, por si se
        # llegase a seguir expandiendo el camino y estos se debieran tener en cuenta.
        contador = len(self.ruta) - 1
        i = self.ruta[contador - 1]
        while i != self.nodo_inicio:
            if self.ruta[contador] in i.hijos:
                i = self.ruta[contador - 2]
                contador -= 1
            else:
                self.ruta.remove(i)
                i = self.ruta[contador - 2]
                contador -= 1

    def imprimir_ruta_pp(self):
        # Método para imprimir la ruta encontrada por el algoritmo
        print("Estrategia Primero en profundidad: ")
        print(" ")
        for i in self.ruta:
            print("      ", i.nombre)
        print(" ")

from Tablero import tablero
from Primero_mejor import alg_primero_mejor as pm
from A_estrella import alg_a_estrella as ae
from Primero_prof import alg_primero_prof as pp


tablero = tablero()

# Uso de estrategia "Primero el mejor"
alg_pm = pm(tablero.nodo_inicial, tablero.nodo_final)
alg_pm.run_pm()
alg_pm.imprimir_ruta_pm()

# Uso de estrategia "A* estrella"
alg_ae = ae(tablero.nodo_inicial, tablero.nodo_final)
alg_ae.run_ae()
alg_ae.imprimir_ruta_ae()

# Uso de estrategia "Primero en profundidad"
alg_pp = pp(tablero.nodo_inicial, tablero.nodo_final)
alg_pp.run_pp()
alg_pp.imprimir_ruta_pp()


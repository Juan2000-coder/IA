from Individuo import Individuo
import random

class Poblacion:
  def __init__(self, largo_genoma, n, prob):
    self.pueblo = self.generar_pueblo(largo_genoma, n)
    self.prob_mutar = prob
    self.mejor = Individuo(largo_genoma)
    self.precio_mejor = 0
    
    
  def generar_pueblo(self, largo_genoma, n):
    pueblo = []
    
    for i in range(n):
      pueblo.append(Individuo(largo_genoma))
    return pueblo

  
  def padres_cruce(self):
    #Se tienen que obtener las probabilidades
      #Se tiene que ordenar en una lista a los individuos segun orden de prob
    #Se tienen que obtener dos nros
    #Se tiene que realizar el cruce, es decir, definir el genoma de los hijos
    total_precio = 0
    self.precio = []

    #Creamos una lista de los precios de los actuales individuos
    for i in self.pueblo:
      self.precio.append(i.calcular_precio())
      total_precio = total_precio + i.calcular_precio()
    
    #Ponderamos el precio de cada indiv sobre el total de costo de esos indiv
      #De este modo se onbtiene una lista de probabilidades
    
    for i in range(len(self.pueblo)):      
      self.precio[i] = (self.pueblo[i].calcular_precio() / total_precio)
    
    #Ordenamos la lista de modo que las probabilidades estén en orden y entre 0 y 1.
    self.ordenar_lista(self.precio)

    
    #For para hacer acumulativo el listado de precios
      #De este modo vamos a cambiar la lista como muestra el siguiente caso ej:
      # [0.52 , 0.24 , 0.13 , 0.11] --> [0.52 , 0.76 , 0.89 , 1]
      #De modo que quede una lista de precios con distr tipo torta entre 0 y 1
    
    
    
    for i in range(len(self.precio)-2):
      self.precio[i+1] =  round(self.precio[i] + self.precio[i+1] , 2)
    self.precio[-1] = 1

    
    
    #Ahora necesitamos que el programa genere dos numeros al azar entre 0 y 1
    #Con los que definiremos cuáles individuos se van a cruzar
    id_padre1 = round(random.uniform(0 , 1) , 2)   #Nro random en [0,1]
    id_padre2 = round(random.uniform(0 , 1) , 2)   #random.random() [0,1)

    #Manera Alternativa-----------------------------------------------------------------
    flag = 0
    for j in self.precio:
      if id_padre1 < j and flag == 0:
        id_padre1 = j
        flag = 1
    flag = 0
    for j in self.precio:
      if id_padre2 < j and flag == 0:
        id_padre2 = j
        flag = 1

    return id_padre1 , id_padre2
        
  
  def cruce(self, id_padre1 , id_padre2):
  
    #Definidos los dos individuos que van a realizar el cruce, se realiza el cruce
    #Se impone una manera de modificar el genoma del hijo
    #Buscamos el genoma del padre1 y padre2 en la poblacion
    genoma_padre1 = self.pueblo[self.precio.index(id_padre1)]
    genoma_padre2 = self.pueblo[self.precio.index(id_padre2)]

    """
    #Manera 1:
      #50% padre1 - 50% padre2
    lg = genoma_padre1.largo_genoma
    genoma_hijo1 = Individuo(lg)
    genoma_hijo2 = Individuo(lg)
    rango_genoma = range(int(lg / 2))
    
    for i in rango_genoma:    #Recorre la primera mitad. Ej: 5 -> 0,1,2,3,4
      genoma_hijo1.genoma[i] = genoma_padre1.genoma[i]
      genoma_hijo2.genoma[i] = genoma_padre2.genoma[i]
      genoma_hijo1.genoma[lg - 1 - i] = genoma_padre2.genoma[lg - 1 - i]
      genoma_hijo2.genoma[lg - 1 - i] = genoma_padre1.genoma[lg - 1 - i]
    """  
    #Manera 2:
      #....
      #30% padre1 - 70% padre2
    lg = genoma_padre1.largo_genoma
    genoma_hijo1 = Individuo(lg)
    genoma_hijo2 = Individuo(lg)
    i = 0
    while i < 3:    #Recorre la primera mitad. Ej: 5 -> 0,1,2,3,4
      genoma_hijo1.genoma[i] = genoma_padre1.genoma[i]
      genoma_hijo2.genoma[i] = genoma_padre2.genoma[i]
      i += 1
    
    while i < 10:
      genoma_hijo1.genoma[9 - i] = genoma_padre2.genoma[9 - i]
      genoma_hijo2.genoma[9 - i] = genoma_padre1.genoma[9 - i]
      i += 1
      
    #Manera 3:
      #....
      #....
    
    return genoma_hijo1 , genoma_hijo2

  def act_poblacion(self, n):
    i = 0
    nueva_poblacion = []
    
    while i != n:
      hijos = []
    
      id_padre1 , id_padre2 = self.padres_cruce()
      hijo1 , hijo2 = self.cruce(id_padre1 , id_padre2)
  
      #Los hijos deben mutar
      hijo1.mutar(self.prob_mutar)
      hijo2.mutar(self.prob_mutar)
      hijos.append(hijo1)
      hijos.append(hijo2)    
      
      #Los hijos deben verificar el peso
      for j in hijos:
        if j.calcular_peso() <= 1000:
          nueva_poblacion.append(hijo1)
        else:
          while j.calcular_peso() > 1000:
            j.mutar(1)      #Probabilidad de mutar del 100%
          nueva_poblacion.append(j)
          
      i += 2

    self.pueblo = nueva_poblacion
    
  def ordenar_lista(self, lista):
    n = len(lista)
    for i in range(n):
      for j in range(0, n - i - 1):
        if lista[j] < lista[j + 1]:  # Cambiamos el signo de comparación
          lista[j], lista[j + 1] = lista[j + 1], lista[j]




  def mejor_individuo(self):
    
    for i in self.pueblo:
      if i.calcular_precio() > self.precio_mejor and i.calcular_peso() <= 1000:
        self.mejor = i
        self.precio_mejor = i.calcular_precio()
    
  
  def imprimir_poblacion(self):
    for i in self.pueblo:
      i.imprimir_individuo()
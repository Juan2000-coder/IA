import random

class Individuo:

  def __init__(self, largo_genoma):
    self.genoma = self.generar_individuo(largo_genoma)
    self.precios = [100, 50, 115, 25, 200, 30, 40, 100, 100, 100]
    self.pesos = [300, 200, 450, 145, 664, 90, 150, 355, 401, 395]
    self.largo_genoma = largo_genoma


  def generar_individuo(self, largo_genoma):
    individuo = []
    for i in range(largo_genoma):
      individuo.append(random.randint(0, 1))
    return individuo


  def calcular_precio(self):
    precio = 0
    for i in range(self.largo_genoma):
      precio += self.genoma[i] * self.precios[i]
    return precio

  def calcular_peso(self):
    peso= 0
    for i in range(self.largo_genoma):
      peso += self.genoma[i] * self.pesos[i]
    return peso


  def mutar(self, prob):
    posicion = random.randint(0, self.largo_genoma - 1)
    if random.random() < prob:       # random.random() nro random entre 0(inc) y 1(exc) 
      if self.genoma[posicion] == 0:
        self.genoma[posicion] = 1
      else:
        self.genoma[posicion] = 0

  def imprimir_individuo(self):
    print("[", end=" ")
    for i in self.genoma:
        print(i, end=" ")
    print("] " , "Precio: " , self.calcular_precio() , "  Peso: " , self.calcular_peso())
from Poblacion import Poblacion

tam_poblacion = 30
largo_genoma = 10
prob_mutar = 0.02
epocas = 600

epoca = 0
pueblo = Poblacion(largo_genoma, tam_poblacion, prob_mutar)
print("Epoca: " , epoca)
pueblo.imprimir_poblacion()

while epoca <= epocas:
  pueblo.act_poblacion(tam_poblacion)
  epoca += 1
  print("Epoca: " , epoca)
  pueblo.imprimir_poblacion()
  
  pueblo.mejor_individuo()

print("")
pueblo.mejor.imprimir_individuo()
  